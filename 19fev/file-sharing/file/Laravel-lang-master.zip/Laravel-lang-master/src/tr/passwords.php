<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Password Reminder Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'password' => 'Parolanız en az altı karakter olmalı ve doğrulama ile eşleşmelidir.',
    'reset'    => 'Parolanız sıfırlandı!',
    'sent'     => 'Parola sıfırlama bağlantınız e-posta ile gönderildi!',
    'token'    => 'Parola sıfırlama adresi/kodu geçersiz.',
    'user'     => 'Bu e-posta adresi ile kayıtlı bir üye bulunmuyor.',
];
