
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `bbp_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `bbp_customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `uid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contacts` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_uid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bbp_customers_uid_unique` (`uid`),
  KEY `bbp_customers_user_uid_foreign` (`user_uid`),
  CONSTRAINT `bbp_customers_user_uid_foreign` FOREIGN KEY (`user_uid`) REFERENCES `bbp_users` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bbp_customers` WRITE;
/*!40000 ALTER TABLE `bbp_customers` DISABLE KEYS */;
INSERT INTO `bbp_customers` VALUES (1,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c69949','Шестаков Виталий Максимович','vsestakova@example.net','951462, Читинская область, город Солнечногорск, пр. Ленина, 52',NULL),(2,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c69adb','Евгения Андреевна Медведевaа','daniil91@example.com','573819, Астраханская область, город Видное, пл. Чехова, 52',NULL),(3,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c69bd1','Мария Владимировна Матвеева','inessa.koklova@example.com','427584, Тюменская область, город Воскресенск, ул. Славы, 01',NULL),(4,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c69cc3','Гурьевaа Фаина Максимовна','valerii54@example.org','710289, Тамбовская область, город Дорохово, шоссе Балканская, 85',NULL),(5,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c69dae','Матвей Владимирович Блиновa','petrov.yn@example.org','930813, Пензенская область, город Павловский Посад, пер. Гагарина, 97',NULL),(6,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c69ea0','Ларионовa Лаврентий Сергеевич','tkonstantinov@example.org','826379, Кемеровская область, город Сергиев Посад, шоссе Сталина, 31',NULL),(7,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c69f89','Ковалёвaа Ольга Львовна','sykovlev@example.org','911153, Томская область, город Зарайск, въезд Сталина, 25',NULL),(8,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c6a06e','Нестеровa Добрыня Александрович','nsukina@example.com','511876, Владимирская область, город Волоколамск, ул. Балканская, 34',NULL),(9,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c6a10d','Витольд Андреевич Белоусов','akim.nikolaeva@example.org','936030, Кемеровская область, город Лотошино, ул. Гоголя, 60',NULL),(10,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c6a1b1','Нестор Александрович Кулагин','zfomin@example.net','079491, Ивановская область, город Люберцы, въезд Косиора, 16',NULL),(11,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c6a249','Барановa Аркадий Романович','ermakov.aleksandra@example.org','691154, Московская область, город Видное, спуск Гоголя, 81',NULL),(12,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c6a2f7','Шиловa Эрик Максимович','martynov.oksana@example.net','035796, Иркутская область, город Домодедово, спуск Сталина, 68',NULL),(13,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c6a39b','Борисовa Родион Александрович','bogdan71@example.org','388734, Свердловская область, город Луховицы, пр. Будапештсткая, 28',NULL),(14,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c6a439','Оксана Львовна Цветкова','evgenii11@example.org','245054, Свердловская область, город Талдом, шоссе Гоголя, 65',NULL),(15,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c6a4da','Милан Фёдорович Карпов','vasileva.antonina@example.net','603034, Пензенская область, город Пушкино, спуск Домодедовская, 37',NULL),(16,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c6a57c','Гурьев Милан Андреевич','alina.pakomov@example.org','799728, Челябинская область, город Раменское, пл. Ломоносова, 25',NULL),(17,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c6a61d','Иосиф Львович Хохловa','kkolobov@example.com','327659, Магаданская область, город Люберцы, ул. Чехова, 54',NULL),(18,'2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'cust-uid5df2603c6a6cb','Носова Жанна Евгеньевна','iersov@example.com','795977, Рязанская область, город Коломна, проезд Ломоносова, 47',NULL);
/*!40000 ALTER TABLE `bbp_customers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bbp_failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `bbp_failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bbp_failed_jobs` WRITE;
/*!40000 ALTER TABLE `bbp_failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbp_failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bbp_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `bbp_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `code` int(11) DEFAULT NULL,
  `named` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kapsula` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buh_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sostav` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bbp_items` WRITE;
/*!40000 ALTER TABLE `bbp_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbp_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bbp_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `bbp_migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bbp_migrations` WRITE;
/*!40000 ALTER TABLE `bbp_migrations` DISABLE KEYS */;
INSERT INTO `bbp_migrations` VALUES (1,'2019_08_19_000000_create_failed_jobs_table',1),(2,'2019_11_11_111037_create_roles_table',1),(3,'2019_11_12_000000_create_users_table',1),(4,'2019_11_12_100000_create_password_resets_table',1),(5,'2019_11_14_201116_create_items_table',1),(6,'2019_11_14_201932_create_customers_table',1),(7,'2019_11_14_202039_create_orders_table',1);
/*!40000 ALTER TABLE `bbp_migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bbp_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `bbp_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `uid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `customer_uid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_uid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `count` int(11) NOT NULL,
  `date_mod` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bbp_orders_uid_unique` (`uid`),
  KEY `bbp_orders_item_id_foreign` (`item_id`),
  KEY `bbp_orders_customer_uid_foreign` (`customer_uid`),
  KEY `bbp_orders_user_uid_foreign` (`user_uid`),
  CONSTRAINT `bbp_orders_customer_uid_foreign` FOREIGN KEY (`customer_uid`) REFERENCES `bbp_customers` (`uid`),
  CONSTRAINT `bbp_orders_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `bbp_items` (`id`),
  CONSTRAINT `bbp_orders_user_uid_foreign` FOREIGN KEY (`user_uid`) REFERENCES `bbp_users` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bbp_orders` WRITE;
/*!40000 ALTER TABLE `bbp_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbp_orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bbp_password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `bbp_password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `bbp_password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bbp_password_resets` WRITE;
/*!40000 ALTER TABLE `bbp_password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbp_password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bbp_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `bbp_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bbp_roles` WRITE;
/*!40000 ALTER TABLE `bbp_roles` DISABLE KEYS */;
INSERT INTO `bbp_roles` VALUES (1,NULL,NULL,NULL,'superadmin'),(2,NULL,NULL,NULL,'admin'),(3,NULL,NULL,NULL,'user');
/*!40000 ALTER TABLE `bbp_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bbp_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `bbp_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '$2y$10$pybKysalH4THREx/T/3ymOEMiJNmR/eqvFdZf4uaLhAwlAwUFoXcq',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` bigint(20) unsigned NOT NULL DEFAULT '3',
  `uid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bbp_users_email_unique` (`email`),
  UNIQUE KEY `bbp_users_uid_unique` (`uid`),
  KEY `bbp_users_role_id_foreign` (`role_id`),
  CONSTRAINT `bbp_users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `bbp_roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bbp_users` WRITE;
/*!40000 ALTER TABLE `bbp_users` DISABLE KEYS */;
INSERT INTO `bbp_users` VALUES (1,'admin','admin@bellbimbo.by','2019-12-12 15:43:55','$2y$10$aGaDwFmHCbaX7CcbaTEaDeJ6qbTSFpFw0mQC/oyVz6Q/MS9iougfK','cA7FJcpgEku5i5xSNWWyQ6HluK6HI7sACQlxDvYVvL7NettJ1m9tAZkdOxKe',NULL,NULL,NULL,'Администратор',1,'uid5df2603b58fb1','202cb962ac59075b964b07152d234b70'),(2,'rovina','rovina@bellbimbo.by','2019-12-12 15:43:55','$2y$10$fEUd52IX6WzyaUcnJUrXcu/w8esy4nTGLVnufHey0f0hjwJ40rxRq','5YeU95mQ0qyjM6uZZoUp',NULL,NULL,NULL,'Ровина Ирина Матвеевна',2,'uid5df2603b6d479','202cb962ac59075b964b07152d234b70'),(3,'evdokimovaa','stepanov.oksana@example.com','2019-12-12 15:43:55','$2y$10$8pOFNqrycMI5aTnk/8zBceWDB0STKbYcIDtjx.lpcduoDSBg7pBXS','rSk190aEMM2ZPqlMLFeT','2019-12-12 15:43:55','2019-12-12 15:43:55',NULL,'Зайцев Трофим Фёдорович',3,'uid5df2603b93263','bd42bb6dd23e4036b58d83fb8dafb994'),(4,'abram','tamara53@example.org','2019-12-12 15:43:55','$2y$10$jVPZi.7ON1PdnC2/tbS6Y.P1vCIDYj2eMHzQD9/3Ub5ealMwdKKoO','wTOmCDheB1eRARrK0way','2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'Киселёвa Руслан Дмитриевич',3,'uid5df2603bab16f','31bc74babe7c85fd3ddf4304b960fa46'),(5,'kostina','raisa43@example.com','2019-12-12 15:43:55','$2y$10$AdhUA52nCweTUYauPBGGeuMLTYhrDIt5u.6HVb6aVIby83hLptH3K','yhe3E0Nkf2jPLLBFG7jP','2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'Роговa Пётр Владимирович',3,'uid5df2603bbf775','81604937c8a234602a7f7306b7197149'),(6,'borisov','larionova.mark@example.org','2019-12-12 15:43:55','$2y$10$/OJlosHwiILGIFNBDnlJkuYpw1wFWGdxShKpj3PFnI9CslPRcvJBe','LyX4Ih9e6aDklaAskArI','2019-12-12 15:43:56','2019-12-12 15:43:56',NULL,'Эмма Александровна Никоновaа',3,'uid5df2603bd3de2','013818dade48ef78a86eecd2b12322a9');
/*!40000 ALTER TABLE `bbp_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

